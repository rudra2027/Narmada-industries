import { Component } from '@angular/core';

@Component({
  selector: 'app-gallery9',
  standalone: true,
  imports: [],
  templateUrl: './gallery9.component.html',
  styleUrl: './gallery9.component.css'
})
export class Gallery9Component {

}
