import { Component } from '@angular/core';

@Component({
  selector: 'app-gallery7',
  standalone: true,
  imports: [],
  templateUrl: './gallery7.component.html',
  styleUrl: './gallery7.component.css'
})
export class Gallery7Component {

}
