import { Component } from '@angular/core';

@Component({
  selector: 'app-gallery8',
  standalone: true,
  imports: [],
  templateUrl: './gallery8.component.html',
  styleUrl: './gallery8.component.css'
})
export class Gallery8Component {

}
