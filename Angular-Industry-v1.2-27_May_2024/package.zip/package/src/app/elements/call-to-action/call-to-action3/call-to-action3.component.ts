import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-call-to-action3',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './call-to-action3.component.html',
  styleUrl: './call-to-action3.component.css'
})
export class CallToAction3Component {

}
