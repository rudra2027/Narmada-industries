import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-call-to-action4',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './call-to-action4.component.html',
  styleUrl: './call-to-action4.component.css'
})
export class CallToAction4Component {

}
