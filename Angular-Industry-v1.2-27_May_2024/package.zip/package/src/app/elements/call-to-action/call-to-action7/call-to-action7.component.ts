import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-call-to-action7',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './call-to-action7.component.html',
  styleUrl: './call-to-action7.component.css'
})
export class CallToAction7Component {

}
