import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-call-to-action1',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './call-to-action1.component.html',
  styleUrl: './call-to-action1.component.css'
})
export class CallToAction1Component {

}
