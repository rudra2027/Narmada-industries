import { Component } from '@angular/core';

@Component({
  selector: 'app-price-table1',
  standalone: true,
  imports: [],
  templateUrl: './price-table1.component.html',
  styleUrl: './price-table1.component.css'
})
export class PriceTable1Component {

}
