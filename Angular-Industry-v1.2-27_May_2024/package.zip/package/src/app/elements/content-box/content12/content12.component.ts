import { Component } from '@angular/core';

@Component({
  selector: 'app-content12',
  standalone: true,
  imports: [],
  templateUrl: './content12.component.html',
  styleUrl: './content12.component.css'
})
export class Content12Component {

}
