import { Component } from '@angular/core';

@Component({
  selector: 'app-content1',
  standalone: true,
  imports: [],
  templateUrl: './content1.component.html',
  styleUrl: './content1.component.css'
})
export class Content1Component {

}
