import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-content6',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './content6.component.html',
  styleUrl: './content6.component.css'
})
export class Content6Component {

}
