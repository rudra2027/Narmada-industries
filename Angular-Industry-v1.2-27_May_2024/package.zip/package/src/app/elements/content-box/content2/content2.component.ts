import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-content2',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './content2.component.html',
  styleUrl: './content2.component.css'
})
export class Content2Component {

}
