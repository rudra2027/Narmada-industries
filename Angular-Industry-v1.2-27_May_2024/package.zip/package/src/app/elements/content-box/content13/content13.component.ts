import { Component } from '@angular/core';

@Component({
  selector: 'app-content13',
  standalone: true,
  imports: [],
  templateUrl: './content13.component.html',
  styleUrl: './content13.component.css'
})
export class Content13Component {

}
