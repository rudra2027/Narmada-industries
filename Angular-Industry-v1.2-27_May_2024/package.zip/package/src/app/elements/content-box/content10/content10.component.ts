import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-content10',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './content10.component.html',
  styleUrl: './content10.component.css'
})
export class Content10Component {

}
