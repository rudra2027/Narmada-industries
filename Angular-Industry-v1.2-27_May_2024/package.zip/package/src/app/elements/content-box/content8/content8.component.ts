import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-content8',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './content8.component.html',
  styleUrl: './content8.component.css'
})
export class Content8Component {

}
