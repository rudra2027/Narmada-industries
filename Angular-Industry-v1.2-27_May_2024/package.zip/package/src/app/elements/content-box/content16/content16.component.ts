import { Component } from '@angular/core';

@Component({
  selector: 'app-content16',
  standalone: true,
  imports: [],
  templateUrl: './content16.component.html',
  styleUrl: './content16.component.css'
})
export class Content16Component {

}
