import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-content5',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './content5.component.html',
  styleUrl: './content5.component.css'
})
export class Content5Component {

}
