import { Component } from '@angular/core';
import { Counter4Component } from '../../counter/counter4/counter4.component';

@Component({
  selector: 'app-content14',
  standalone: true,
  imports: [Counter4Component],
  templateUrl: './content14.component.html',
  styleUrl: './content14.component.css'
})
export class Content14Component {

}
