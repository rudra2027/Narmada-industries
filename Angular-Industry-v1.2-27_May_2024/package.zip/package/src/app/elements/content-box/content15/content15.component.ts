import { Component } from '@angular/core';

@Component({
  selector: 'app-content15',
  standalone: true,
  imports: [],
  templateUrl: './content15.component.html',
  styleUrl: './content15.component.css'
})
export class Content15Component {

}
