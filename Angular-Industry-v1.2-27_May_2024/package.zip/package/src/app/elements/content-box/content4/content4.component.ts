import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-content4',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './content4.component.html',
  styleUrl: './content4.component.css'
})
export class Content4Component {

}
