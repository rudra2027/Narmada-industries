import { Component } from '@angular/core';

@Component({
  selector: 'app-query-form3',
  standalone: true,
  imports: [],
  templateUrl: './query-form3.component.html',
  styleUrl: './query-form3.component.css'
})
export class QueryForm3Component {

}
