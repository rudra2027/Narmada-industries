import { Component } from '@angular/core';

@Component({
  selector: 'app-search-form2',
  standalone: true,
  imports: [],
  templateUrl: './search-form2.component.html',
  styleUrl: './search-form2.component.css'
})
export class SearchForm2Component {

}
