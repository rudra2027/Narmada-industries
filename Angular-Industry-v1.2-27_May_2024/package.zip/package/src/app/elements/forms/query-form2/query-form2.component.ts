import { Component } from '@angular/core';

@Component({
  selector: 'app-query-form2',
  standalone: true,
  imports: [],
  templateUrl: './query-form2.component.html',
  styleUrl: './query-form2.component.css'
})
export class QueryForm2Component {

}
