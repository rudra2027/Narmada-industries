import { NgClass } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Navigation1Component } from '../../navigation/navigation1/navigation1.component';

@Component({
  selector: 'app-header-light5',
  standalone: true,
  imports: [
    RouterLink,
    NgClass,
    Navigation1Component
  ],
  templateUrl: './header-light5.component.html',
  styleUrl: './header-light5.component.css'
})
export class HeaderLight5Component {
  collapseToggle: boolean = false;
  searchToggle: boolean = false;

  constructor() {}

  ngOnInit(): void {}

  clickEvent() {
    this.collapseToggle = !this.collapseToggle;
  }

  searchOpen() {
    this.searchToggle = !this.searchToggle;
  }
}
