import { Component } from '@angular/core';

@Component({
  selector: 'app-services-element13',
  standalone: true,
  imports: [],
  templateUrl: './services-element13.component.html',
  styleUrl: './services-element13.component.css'
})
export class ServicesElement13Component {

}
