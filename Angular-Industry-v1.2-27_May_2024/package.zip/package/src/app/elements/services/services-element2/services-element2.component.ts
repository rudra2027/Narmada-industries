import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-services-element2',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './services-element2.component.html',
  styleUrl: './services-element2.component.css'
})
export class ServicesElement2Component {

}
