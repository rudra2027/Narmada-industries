import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-services-element12',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './services-element12.component.html',
  styleUrl: './services-element12.component.css'
})
export class ServicesElement12Component {

}
