import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-services-element11',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './services-element11.component.html',
  styleUrl: './services-element11.component.css'
})
export class ServicesElement11Component {

}
