import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-services-element3',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './services-element3.component.html',
  styleUrl: './services-element3.component.css'
})
export class ServicesElement3Component {

}
