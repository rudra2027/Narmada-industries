import { Component } from '@angular/core';

@Component({
  selector: 'app-services-element1',
  standalone: true,
  imports: [],
  templateUrl: './services-element1.component.html',
  styleUrl: './services-element1.component.css'
})
export class ServicesElement1Component {

}
