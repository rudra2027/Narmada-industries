import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-services-element17',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './services-element17.component.html',
  styleUrl: './services-element17.component.css'
})
export class ServicesElement17Component {

}
