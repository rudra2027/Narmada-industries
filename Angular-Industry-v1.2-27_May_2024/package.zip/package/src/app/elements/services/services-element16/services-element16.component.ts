import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-services-element16',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './services-element16.component.html',
  styleUrl: './services-element16.component.css'
})
export class ServicesElement16Component {

}
