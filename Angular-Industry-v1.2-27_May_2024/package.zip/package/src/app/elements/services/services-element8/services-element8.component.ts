import { Component } from '@angular/core';

@Component({
  selector: 'app-services-element8',
  standalone: true,
  imports: [],
  templateUrl: './services-element8.component.html',
  styleUrl: './services-element8.component.css'
})
export class ServicesElement8Component {

}
