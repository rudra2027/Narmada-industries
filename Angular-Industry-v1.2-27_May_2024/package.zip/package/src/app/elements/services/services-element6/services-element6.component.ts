import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-services-element6',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './services-element6.component.html',
  styleUrl: './services-element6.component.css'
})
export class ServicesElement6Component {

}
