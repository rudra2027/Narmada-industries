import { Component } from '@angular/core';

@Component({
  selector: 'app-services-element19',
  standalone: true,
  imports: [],
  templateUrl: './services-element19.component.html',
  styleUrl: './services-element19.component.css'
})
export class ServicesElement19Component {

}
