import { Component } from '@angular/core';

@Component({
  selector: 'app-services-element18',
  standalone: true,
  imports: [],
  templateUrl: './services-element18.component.html',
  styleUrl: './services-element18.component.css'
})
export class ServicesElement18Component {

}
