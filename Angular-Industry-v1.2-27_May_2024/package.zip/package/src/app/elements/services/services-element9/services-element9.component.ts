import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-services-element9',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './services-element9.component.html',
  styleUrl: './services-element9.component.css'
})
export class ServicesElement9Component {

}
