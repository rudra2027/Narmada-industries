import { Component } from '@angular/core';

@Component({
  selector: 'app-services-element5',
  standalone: true,
  imports: [],
  templateUrl: './services-element5.component.html',
  styleUrl: './services-element5.component.css'
})
export class ServicesElement5Component {

}
