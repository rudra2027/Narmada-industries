import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-box4',
  standalone: true,
  imports: [],
  templateUrl: './icon-box4.component.html',
  styleUrl: './icon-box4.component.css'
})
export class IconBox4Component {

}
