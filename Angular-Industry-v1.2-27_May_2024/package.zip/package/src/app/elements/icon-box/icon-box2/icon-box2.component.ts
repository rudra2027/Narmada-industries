import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-box2',
  standalone: true,
  imports: [],
  templateUrl: './icon-box2.component.html',
  styleUrl: './icon-box2.component.css'
})
export class IconBox2Component {

}
