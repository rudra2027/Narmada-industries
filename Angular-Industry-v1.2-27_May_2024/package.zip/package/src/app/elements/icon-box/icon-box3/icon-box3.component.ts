import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-box3',
  standalone: true,
  imports: [],
  templateUrl: './icon-box3.component.html',
  styleUrl: './icon-box3.component.css'
})
export class IconBox3Component {

}
