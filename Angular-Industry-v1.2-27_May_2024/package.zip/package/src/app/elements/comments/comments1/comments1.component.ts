import { Component } from '@angular/core';

@Component({
  selector: 'app-comments1',
  standalone: true,
  imports: [],
  templateUrl: './comments1.component.html',
  styleUrl: './comments1.component.css'
})
export class Comments1Component {

}
