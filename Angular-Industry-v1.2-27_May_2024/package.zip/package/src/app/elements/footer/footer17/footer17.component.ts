import { Component } from '@angular/core';

@Component({
  selector: 'app-footer17',
  standalone: true,
  imports: [],
  templateUrl: './footer17.component.html',
  styleUrl: './footer17.component.css'
})
export class Footer17Component {
  email = 'exemple@gmail.com';
}
