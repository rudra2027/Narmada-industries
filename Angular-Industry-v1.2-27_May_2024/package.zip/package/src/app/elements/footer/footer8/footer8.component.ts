import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-footer8',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './footer8.component.html',
  styleUrl: './footer8.component.css'
})
export class Footer8Component {

}
