import { Component } from '@angular/core';

@Component({
  selector: 'app-footer2',
  standalone: true,
  imports: [],
  templateUrl: './footer2.component.html',
  styleUrl: './footer2.component.css'
})
export class Footer2Component {

}
