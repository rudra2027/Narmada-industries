import { Component } from '@angular/core';

@Component({
  selector: 'app-footer1',
  standalone: true,
  imports: [],
  templateUrl: './footer1.component.html',
  styleUrl: './footer1.component.css'
})
export class Footer1Component {

}
